<?php
$cfg['dbhost']='127.0.0.1'; //mysql host
$cfg['dbname']='ftpusers';  //mysql db name
$cfg['dbuser']='root';		//mysql user
$cfg['dbpasswd']='ftppasswd';		//mysql password

//ftp config
$cfg['page']=15;
//ftp passwd type : TEXT/CRYPT/MD5
$cfg['passwdtype']='MD5';
//ftp default
$cfg['uid']=500;  //uid
$cfg['gid']=500;	//gid
$cfg['dir']='/data/ftproot/'; //dir
$cfg['qf']=0;	//quotafiles
$cfg['qs']=10240000;	//quotasize
$cfg['ul']=0;	//ULBandwidth
$cfg['dl']=0;	//DLBandwidth
$cfg['ur']=0;	//ULRatio
$cfg['dr']=0;	//DLRatio
$cfg['status']=1; //status
$cfg['ip']= '*';	//ipaddress
?>
